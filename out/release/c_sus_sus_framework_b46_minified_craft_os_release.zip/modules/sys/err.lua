local SF,Tu,Ge=ENV(3,10,14)Control.error=function(str,...)local l={...}Control.Iterator=function()Ge("cssf["..(Control.line or"X").."]:"..SF(str,Tu(l)),3)end
end