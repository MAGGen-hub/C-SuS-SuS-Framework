
local stx,Cp,Ss,Ti,Gp,GS,TS=[[O
?. ?: ?( ?{ ?[ ?" ?'
]],function()end,ENV(6,7,13,18,23)local m,M,c=GS({},{__call=function()end,__newindex=function()end}),{__index=function()return Cp end},TS{7,3,10}local r,R=function(obj)return obj==nil and m or obj end,function(obj)return obj==nil and M or GS({},{__index=function(s,i)return obj[i]or Cp end})end
C:load_libs"code".cssc"runtime""op_stack"()"syntax_loader"(3)(stx,{O=function(...)for k,v in Gp{...}do
Operators[v]=function()local t,i,d=Ss(v,2)i,d=Cdata.tb_while(Cdata.skip_tb)if not c[d[1]]then C.error("Unexpected '?' after '%s'!",Result[i])end
Event.run(2,"?x",2,1)Event.run("all","?x",2,1)if t==":"then
Runtime.reg("__cssc__op_d_nc","nilF.dual")Cssc.op_conf({{" ",5},{"__cssc__op_d_nc",3}},Cdata.opts["."][1],false,false,true)else
Runtime.reg("__cssc__op_nc","nilF.basic")Cssc.op_conf({{" ",5},{"__cssc__op_nc",3}},Cdata.opts["."][1],false,false,true)end
Text.split_seq(nil,1)end
end
end})Runtime.build("nilF.dual",R)Runtime.build("nilF.basic",r)