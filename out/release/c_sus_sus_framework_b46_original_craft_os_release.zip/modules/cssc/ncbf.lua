local r = C:load_lib"text.dual_queue.make_react"("..",2)
Operators[".."]=function()if 6==Cdata[#Cdata][1]then Cssc.inject(" ",5)end r()end